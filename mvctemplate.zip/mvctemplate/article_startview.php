
<?php
function article_start(){
  
  ?>
  <div class="row">
    <div class="col-xs-12 col-md-8">col-xs-12 col-md-8</div>
    <div class="col-xs-6 col-md-4">.col-xs-6 .col-md-4</div>  
  </div>
  
  <?php
  
}
