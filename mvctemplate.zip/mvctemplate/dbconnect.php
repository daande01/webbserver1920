
<?php




function anslutdb(){

  try {
    $pdo = new PDO('mysql:host=localhost;dbname=sitetemplate2016; charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    /*
    PDO::ERRMODE_SILENT – database-related errors will be ignored.
    PDO::ERRMODE_WARNING – database-related errors will cause a warning to be emitted, but execution will continue.
    PDO::ERRMODE_EXCEPTION – database-related errors will cause a PDOException to be thrown.

    Kollationering handlar dock om sortering. I tyskan sorteras ä som a och ö som o. I svenskan ligger de som bekant i slutet av alfabetet.

    Du skall därför ha en kollationering som stämmer överens med sidans språk (och teckenkodning). Antar att du har en svensk sida.

    Om du kör med latin-1 som teckenkodning skall du ha latin1_swedish_ci som kollationering.
    Om du kör med utf-8 som teckenkodning skall du ha utf8_swedish_ci som kollationering.
    */
  } catch(PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
  }


  return $conn;
}

?>
